// Basic site-wide enhancements:
// - Animated counters on home page
// - Mobile navigation toggle
// - Scroll reveal for elements marked with [data-animate]
// - Lightweight demo validation for the contact form

document.addEventListener('DOMContentLoaded', () => {
  const yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  /* Mobile navigation */
  const mobileToggle = document.getElementById('mobile-nav-toggle');
  const mobileMenu = document.getElementById('mobile-nav-menu');
  if (mobileToggle && mobileMenu) {
    mobileToggle.addEventListener('click', () => {
      const expanded = mobileToggle.getAttribute('aria-expanded') === 'true';
      mobileToggle.setAttribute('aria-expanded', String(!expanded));
      mobileMenu.classList.toggle('hidden');
    });
  }

  /* Animated counters on home page */
  const counters = document.querySelectorAll('[data-counter]');
  if (counters.length) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const el = entry.target;
          const target = Number(el.getAttribute('data-target') || '0');
          const suffix = el.getAttribute('data-suffix') || '+';
          const duration = 1200;
          const start = performance.now();

          const step = (ts) => {
            const progress = Math.min((ts - start) / duration, 1);
            const current = Math.floor(progress * target);
            el.textContent = `${current}${suffix}`;
            if (progress < 1) {
              requestAnimationFrame(step);
            }
          };

          requestAnimationFrame(step);
          obs.unobserve(el);
        });
      },
      { threshold: 0.4 }
    );
    counters.forEach((counter) => observer.observe(counter));
  }

  /* Scroll reveal */
  const animated = document.querySelectorAll('[data-animate]');
  if (animated.length) {
    const revealObserver = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    animated.forEach((el) => revealObserver.observe(el));
  }

  /* Contact form demo validation (front-end only) */
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const requiredFields = ['name', 'email', 'service', 'message'];
      let isValid = true;

      requiredFields.forEach((field) => {
        const input = contactForm.querySelector(`[name="${field}"]`);
        const errorEl = contactForm.querySelector(
          `[data-error-for="${field}"]`
        );
        if (!input) return;
        const value = String(input.value || '').trim();
        if (!value) {
          isValid = false;
          if (errorEl) {
            errorEl.textContent = 'This field is required.';
          }
        } else if (field === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          isValid = false;
          if (errorEl) {
            errorEl.textContent = 'Please enter a valid email address.';
          }
        } else if (errorEl) {
          errorEl.textContent = '';
        }
      });

      const consent = contactForm.querySelector('#consent');
      if (consent && !consent.checked) {
        isValid = false;
      }

      if (!isValid) return;

      // Demo success state
      const statusEl = document.getElementById('form-status');
      if (statusEl) {
        statusEl.classList.remove('hidden');
      }
      contactForm.reset();
    });
  }
});


